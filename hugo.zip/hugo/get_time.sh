#!/bin/bash

echo "Current time : $now" >> /home2/minwtcom/public_web/hugo/log.txt
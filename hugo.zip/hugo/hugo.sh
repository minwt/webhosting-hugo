#！/bin/bash

cd /home2/minwtcom/public_web/hugo/site
./hugo
rsync -avh --delete --ignore-errors --chmod=Du=rwx,Dg=rx,Do=rx,Fu=rw,Fg=r,Fo=r /home2/minwtcom/public_web/hugo/site/public/ /home2/minwtcom/public_web/hugo.mwt.tw/
rm -rf public